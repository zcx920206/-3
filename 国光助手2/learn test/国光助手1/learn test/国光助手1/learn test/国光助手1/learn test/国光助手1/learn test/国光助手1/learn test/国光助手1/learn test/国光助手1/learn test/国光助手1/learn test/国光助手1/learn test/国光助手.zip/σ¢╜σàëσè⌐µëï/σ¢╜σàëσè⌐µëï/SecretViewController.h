//
//  SecretViewController.h
//  国光助手
//
//  Created by 赵楚欣 on 15/12/16.
//  Copyright © 2015年 zhaochuxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecretViewController : UIViewController

@end
